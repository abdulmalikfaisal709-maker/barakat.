import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabasePublishableKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isNotEmpty && supabasePublishableKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, publishableKey: supabasePublishableKey);
  }
  runApp(const BarakatApp());
}

class BarakatApp extends StatelessWidget {
  const BarakatApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بركات',
      locale: const Locale('ar'),
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.green),
      home: const Directionality(textDirection: TextDirection.rtl, child: HomePage()),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [OffersPage(), OrdersPage(), FavoritesPage(), AccountPage()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بركات'), centerTitle: true),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'طلباتي'),
          NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

class OffersPage extends StatelessWidget {
  const OffersPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'ابحث عن عرض أو متجر', border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
        const SizedBox(height: 20),
        Text('أنقذ الطعام ووفر المال', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('عروض فائض الطعام من المطاعم والمخابز والمتاجر في صنعاء.'),
        const SizedBox(height: 24),
        const _OfferCard(title: 'كيس مفاجآت المخبز', store: 'مخبز تجريبي', oldPrice: '3000 ر.ي', price: '1200 ر.ي', remaining: '5 متبقية'),
        const _OfferCard(title: 'وجبة نهاية اليوم', store: 'مطعم تجريبي', oldPrice: '5000 ر.ي', price: '2000 ر.ي', remaining: '3 متبقية'),
      ],
    );
  }
}

class _OfferCard extends StatelessWidget {
  final String title, store, oldPrice, price, remaining;
  const _OfferCard({required this.title, required this.store, required this.oldPrice, required this.price, required this.remaining});
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const CircleAvatar(child: Icon(Icons.restaurant)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), Text(store)]))]),
          const SizedBox(height: 14),
          Row(children: [Text(oldPrice, style: const TextStyle(decoration: TextDecoration.lineThrough)), const SizedBox(width: 12), Text(price, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), const Spacer(), Text(remaining)]),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: () {}, child: const Text('احجز العرض'))),
        ]),
      ),
    );
  }
}

class OrdersPage extends StatelessWidget { const OrdersPage({super.key}); @override Widget build(BuildContext context) => const Center(child: Text('طلباتك ستظهر هنا')); }
class FavoritesPage extends StatelessWidget { const FavoritesPage({super.key}); @override Widget build(BuildContext context) => const Center(child: Text('العروض المفضلة ستظهر هنا')); }
class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.account_circle, size: 80), const SizedBox(height: 16), const Text('حساب بركات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 12), Text(supabaseUrl.isEmpty ? 'جاهز للربط مع Supabase' : 'متصل بإعدادات Supabase'), const SizedBox(height: 20), SizedBox(width: double.infinity, child: FilledButton(onPressed: () {}, child: const Text('تسجيل الدخول / إنشاء حساب')))]));
}
