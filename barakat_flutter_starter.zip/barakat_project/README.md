# بركات

نسخة أولية من مشروع Flutter لتطبيق بركات.

## قبل البناء
هذا المجلد يحتوي الملفات التي تستبدل داخل مشروع Flutter جديد.

1. أنشئ المشروع: `flutter create barakat`
2. استبدل `lib/` و `pubspec.yaml` بالملفات هنا.
3. نفذ `flutter pub get`.
4. ابنِ مع بيانات Supabase عبر dart-define:

`flutter build apk --release --dart-define=SUPABASE_URL=YOUR_URL --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_KEY`

لا تستخدم Secret key داخل التطبيق.
